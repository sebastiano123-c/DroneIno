#define ALTITUDE_SENSOR_ADDRESS 0x76             // if not working, try 0x77
