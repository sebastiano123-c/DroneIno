var searchData=
[
  ['face_5fcolor_5fblack_0',['FACE_COLOR_BLACK',['../app__httpd_8cpp.html#a8ecdb1a837dd7e777eed1654a99547b8',1,'app_httpd.cpp']]],
  ['face_5fcolor_5fblue_1',['FACE_COLOR_BLUE',['../app__httpd_8cpp.html#a4008bcea96ef431371b6fdd2ae77dbbf',1,'app_httpd.cpp']]],
  ['face_5fcolor_5fcyan_2',['FACE_COLOR_CYAN',['../app__httpd_8cpp.html#a71471dbc5fc5910306e8d533dcff7b34',1,'app_httpd.cpp']]],
  ['face_5fcolor_5fgreen_3',['FACE_COLOR_GREEN',['../app__httpd_8cpp.html#a75746f07d879f351a0e4f53a0536d3a4',1,'app_httpd.cpp']]],
  ['face_5fcolor_5fpurple_4',['FACE_COLOR_PURPLE',['../app__httpd_8cpp.html#a4a25c64f5cb36d29d4abcaa343c00135',1,'app_httpd.cpp']]],
  ['face_5fcolor_5fred_5',['FACE_COLOR_RED',['../app__httpd_8cpp.html#afa6b55a66c5b733e36a480522265fa2c',1,'app_httpd.cpp']]],
  ['face_5fcolor_5fwhite_6',['FACE_COLOR_WHITE',['../app__httpd_8cpp.html#a2db88fbbf8fb02d7e84d5a8fa3388e66',1,'app_httpd.cpp']]],
  ['face_5fcolor_5fyellow_7',['FACE_COLOR_YELLOW',['../app__httpd_8cpp.html#a6e6ff511ff346705d4f5f56380163b7b',1,'app_httpd.cpp']]],
  ['face_5fid_5fsave_5fnumber_8',['FACE_ID_SAVE_NUMBER',['../app__httpd_8cpp.html#ab28c27ee7095c6a3266c0bf7cdd70f4c',1,'app_httpd.cpp']]]
];
