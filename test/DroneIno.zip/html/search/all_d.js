var searchData=
[
  ['off_0',['OFF',['../_constants_8h.html#a29e413f6725b2ba32d165ffaa35b01e5',1,'Constants.h']]],
  ['on_1',['ON',['../_constants_8h.html#ad76d1750a6cdeebd506bfcd6752554d2',1,'Constants.h']]],
  ['osrs_5fp_2',['osrs_p',['../_globals_8h.html#a4e868270c192031001dd3515a251f0c8',1,'Globals.h']]],
  ['osrs_5ft_3',['osrs_t',['../_globals_8h.html#a823323caf3fe06872695088b65cff37b',1,'Globals.h']]]
];
