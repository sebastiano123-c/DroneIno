var searchData=
[
  ['voltagepartitor_0',['voltagePartitor',['../_battery_8ino.html#a0944eeb7d7d454d0b656b8d4ac0d5ae8',1,'Battery.ino']]]
];
