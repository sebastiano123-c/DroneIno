var searchData=
[
  ['trimposition_0',['trimPosition',['../structtrim_position.html',1,'']]]
];
