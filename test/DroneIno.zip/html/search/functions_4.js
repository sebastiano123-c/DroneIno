var searchData=
[
  ['fromwidthtovbattery_0',['fromWidthToVBattery',['../_battery_8ino.html#a0a8a49caabff18e8cb92948d432546ff',1,'Battery.ino']]],
  ['fromwidthtovpin_1',['fromWidthToVPin',['../_battery_8ino.html#aaa54127ddeec0cd653eaba94d2716fed',1,'Battery.ino']]]
];
