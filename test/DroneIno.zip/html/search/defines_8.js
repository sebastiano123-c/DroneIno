var searchData=
[
  ['index_5fov2640_5fhtml_5fgz_5flen_0',['index_ov2640_html_gz_len',['../camera__index_8h.html#a3e9856444509ebbb38f627843790be46',1,'camera_index.h']]],
  ['index_5fov3660_5fhtml_5fgz_5flen_1',['index_ov3660_html_gz_len',['../camera__index_8h.html#af54749bfdc81fcf5b5aa529768b1bd75',1,'camera_index.h']]]
];
