var searchData=
[
  ['globals_2eh_0',['Globals.h',['../_globals_8h.html',1,'']]],
  ['gyroscope_2eino_1',['Gyroscope.ino',['../_gyroscope_8ino.html',1,'']]]
];
