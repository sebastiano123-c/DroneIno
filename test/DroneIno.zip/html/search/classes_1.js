var searchData=
[
  ['ra_5ffilter_5ft_0',['ra_filter_t',['../structra__filter__t.html',1,'']]]
];
