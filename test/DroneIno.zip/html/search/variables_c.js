var searchData=
[
  ['osrs_5fp_0',['osrs_p',['../_globals_8h.html#a4e868270c192031001dd3515a251f0c8',1,'Globals.h']]],
  ['osrs_5ft_1',['osrs_t',['../_globals_8h.html#a823323caf3fe06872695088b65cff37b',1,'Globals.h']]]
];
