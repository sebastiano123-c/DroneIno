var searchData=
[
  ['setup_2eino_0',['Setup.ino',['../_setup_8ino.html',1,'']]]
];
