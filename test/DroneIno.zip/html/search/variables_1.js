var searchData=
[
  ['barometercounter_0',['barometerCounter',['../_globals_8h.html#aee6bd9ed8d0e026d9958bd272a10db24',1,'Globals.h']]],
  ['barometermode_1',['barometerMode',['../_globals_8h.html#afc833aa35e8eb5df1d1284ae0d79258e',1,'Globals.h']]],
  ['batterypercent_2',['batteryPercent',['../_globals_8h.html#a81300fa38d71527c821c36bc290aa2ec',1,'Globals.h']]],
  ['batterypercentage_3',['batteryPercentage',['../telemetry_8h.html#ae476377a15b02d58e1dd3ec3678a3ccc',1,'batteryPercentage():&#160;WiFiTelemetry.ino'],['../_wi_fi_telemetry_8ino.html#ae476377a15b02d58e1dd3ec3678a3ccc',1,'batteryPercentage():&#160;WiFiTelemetry.ino']]],
  ['batteryvoltage_4',['batteryVoltage',['../_globals_8h.html#ac72c35f17f08d2e1bb10271c4fb5f2c6',1,'Globals.h']]]
];
