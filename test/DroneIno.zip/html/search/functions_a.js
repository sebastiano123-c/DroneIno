var searchData=
[
  ['printeeprom_0',['printEEPROM',['../_initialize_8ino.html#a725f5dfc6ec54096ad6cad2439399aca',1,'Initialize.ino']]],
  ['printgyroscopestatus_1',['printGyroscopeStatus',['../_gyroscope_8ino.html#a089b1246ef1031f6bf913c35103fd82f',1,'Gyroscope.ino']]],
  ['printsignals_2',['printSignals',['../receiver_routines_8ino.html#a06805c2615c5da001187b76759692f2e',1,'receiverRoutines.ino']]],
  ['processor_3',['processor',['../_wi_fi_8ino.html#a0c021f9721c3b479757f8e1b40624b6c',1,'WiFi.ino']]]
];
