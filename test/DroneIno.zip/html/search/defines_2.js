var searchData=
[
  ['camera_5fmodel_5fai_5fthinker_0',['CAMERA_MODEL_AI_THINKER',['../_wi_fi_telemetry_8ino.html#af3ad6cce87c9d1876247f85e3cece96e',1,'WiFiTelemetry.ino']]],
  ['code_1',['CODE',['../camera__index_8h.html#ae6527c8381eb3f23b7fd6d6efec6ffc7',1,'camera_index.h']]]
];
