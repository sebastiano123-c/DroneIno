var searchData=
[
  ['batteryvoltagecompensation_0',['batteryVoltageCompensation',['../_battery_8ino.html#ae479d42f5968a848f4d1478350fa42e7',1,'Battery.ino']]],
  ['beginuartcom_1',['beginUARTCOM',['../telemetry_8cpp.html#afeb2a8bb55027eb294b43103551797ac',1,'beginUARTCOM():&#160;telemetry.cpp'],['../telemetry_8h.html#afeb2a8bb55027eb294b43103551797ac',1,'beginUARTCOM():&#160;telemetry.cpp']]]
];
