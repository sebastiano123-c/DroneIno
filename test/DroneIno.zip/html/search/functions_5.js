var searchData=
[
  ['getacc_0',['getAcc',['../check_gyro_8ino.html#a2e3a52d9e18ca2f3527a32e487cfd2fb',1,'checkGyro.ino']]],
  ['getbatteryvoltage_1',['getBatteryVoltage',['../_battery_8ino.html#a8049e4a57d49f7a0c6428cbfd014db52',1,'Battery.ino']]],
  ['getgyro_2',['getGyro',['../check_gyro_8ino.html#a6f06a41ea450ea4a86b06d59834dce82',1,'checkGyro.ino']]],
  ['getgyrosignal_3',['getGyroSignal',['../check_gyro_8ino.html#ae1345c53a374c3feea1fc50e62571d9a',1,'checkGyro.ino']]],
  ['gyro_5fsignalen_4',['gyro_signalen',['../_setup_8ino.html#ad78c7a02600adea93cdc84b51301760e',1,'Setup.ino']]]
];
