#include <stdio.h>
#include <iostream>
#include <string>

const int dataTransferSize = 5;

int main(){


    int indices [dataTransferSize];
    std::string dataTransfer[dataTransferSize];

    std::string str = "1.,2.,3.,4.,5.";
    std::cout << str.substr(4, 2) << std::endl;

    int i = 0;
    indices[i] = str.find(',');
    printf("i%i:%i\n",i,indices[i]);
    for( i = 1; i < dataTransferSize-1; i++){
        indices[i] = str.find(',', indices[i-1]+1);
        printf("i%i:%i\n",i,indices[i]);
    }

    i = 0;
    dataTransfer[i] = str.substr(0, indices[i]);
    printf("%i: %s \n", i, dataTransfer[i]);
    for( i = 1; i < dataTransferSize - 1; i++){
        dataTransfer[i] = str.substr(indices[i-1] + 1, indices[i]);
        printf("%i: %s \n", i, dataTransfer[i].c_str());
    }
    dataTransfer[dataTransferSize - 1] = str.substr(indices[dataTransferSize - 1] + 1);
    printf( "%i: %s \n", dataTransferSize - 1, dataTransfer[dataTransferSize - 1].c_str() );
}