<?php
$_GET['/get']
>