#include <stdio.h>
#define NERO   0
#define BIANCO 1
#define PEPE NERO

int main(){
    #if PEPE == BIANCO
        printf("BAINCO");
    #elif PEPE == NERO
        printf("NERO");
    #endif

    return 0;
}