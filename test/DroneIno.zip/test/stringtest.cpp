#include <stdio.h>
#include <string>

int main(){
    float PID_D_GAIN_ROLL = 2.;
    std::string xxx = "<html><head><title>stringTest</title></head><body>m";
    xxx += std::to_string(PID_D_GAIN_ROLL);
    xxx += "</body></html>";

    const char* index_html = xxx.c_str();//index_html1.c_str();
    printf(index_html);
}