#include <math.h>
#include <cstdio>

float vin = 11.1 - 0.7;
float v32 = 4.8;
float v24 = 3.2;
float r3, r2, r4, vout1, vout2;

float drop1(float r2, float r3, float r4){
    return (r2+r4)/(r4+r2+r3);
}

float drop2(float r2, float r4){
    return r4/(r4+r2);
}

int main(){
    for (int i = 0; i < 200; i++){
        r3 = (float)i/10.;
        for (int j = 0; j < 200; j++){
            r2 = (float)j/10.;
            for (int k = 0; k < 200; k++){
                r4 = (float)k/10.;
                vout1 = vin * drop1 (r2, r3, r4);
                vout2 = vout1 * drop2 (r2, r4);
                if(abs(vout1 - v32) < 1e-3 && abs(vout2 - v24) < 1e-3) {
                    printf("vout1: "); printf("%.6f",(vout1));
                    printf(", vout2: "); printf("%.6f",(vout2));
                    printf(", r3: "); printf("%.6f",r3);
                    printf(", r2: "); printf("%.6f",r2);
                    printf(", r4: "); printf("%.6f\n",r4);
                }
            }
        }
    }
}